import {experienceTurns} from './calendar.js';
export const MEMORABLE_OPENING='오늘 하루 중 특히 기억에 남거나, 그림일기로 남기고 싶은 일이 있었나요?';
export const DAILY_FALLBACK='괜찮아요. 그럼 오늘은 어떻게 보내셨어요? 식사나 잠깐의 산책처럼 작은 이야기도 좋아요.';
const CHANGE_TOPIC='괜찮아요. 그 이야기는 여기까지 해도 돼요. 오늘 다른 일 중 편하게 들려주고 싶은 것이 있나요?';
function reluctant(answer){return /딱히.*없|별(?:다른|로)?.*없|이야기.*없|할\s*말.*없|말할.*없|말하고\s*싶지|얘기.*싫|이야기.*싫|다른\s*(?:얘기|이야기)|불편|부담|무거(?:웠|워)/.test(answer);}
function stopRequested(answer){return /쉬고\s*싶|그만|여기까지|피곤|지쳤|기억(?:이)?\s*안|모르겠|생각이\s*안/.test(answer);}
export function conversationGuard({turns}){
 if(!turns.length)return null;
 const last=turns.at(-1),answer=last.answer.trim();
 const hasStory=experienceTurns(turns).some(t=>t.answer.trim()&&!reluctant(t.answer)&&!stopRequested(t.answer)&&!/^(?:없어요|아니요|글쎄)/.test(t.answer));
 const end=()=>hasStory?{question:'괜찮아요. 들려주신 이야기만으로 오늘 기록을 정리할게요.',ready:true}:{question:'더 말씀하지 않으셔도 괜찮아요. 잠시 쉬었다가 이어가요.',ready:false,rest:true};
 const ordinaryStory=contextOf([last]).activity;
 if(turns.length===1&&last.question.includes('그림일기로 남기고 싶은')&&!ordinaryStory&&(!answer||/없|딱히|별다른|모르겠|기억.*안|생각.*안/.test(answer)))return {question:DAILY_FALLBACK,ready:false,broadenedTopic:true};
 if(last.question===DAILY_FALLBACK&&!ordinaryStory&&(!answer||/없|아니|모르겠|기억.*안/.test(answer)))return {question:'괜찮아요. 잠시 쉬었다가 작은 이야기 하나가 떠오르면 다시 들려주세요.',ready:false,rest:true};
 if(stopRequested(answer))return end();
 if(last.question===CHANGE_TOPIC&&(!answer||/^(?:딱히(?:는)?\s*)?(?:없|아니|글쎄|그냥\s*그랬)|^별(?:다른|로)?.*없/.test(answer)&&answer.length<35))return end();
 if(!answer||reluctant(answer)){
  if(turns.slice(0,-1).some(t=>!t.answer.trim()||reluctant(t.answer)||t.question===CHANGE_TOPIC))return end();
  return {question:CHANGE_TOPIC,ready:false,topicShift:true};
 }
 return null;
}
export function contextOf(turns) {
  const text=turns.map(t=>t.answer).join(' ');
  return {text,hasStory:turns.some(t=>t.answer.trim()),
    company:/혼자|딸|아들|친구|남편|아내|가족|손주|손녀|손자|동생|언니|누나|형|오빠|부부|이웃|어머니|아버지|같이|함께/.test(text),
    feeling:/기분|행복|즐거|즐겁|좋았|좋아|좋더|뿌듯|편안|편했|속상|슬펐|슬프|외로|쓸쓸|고마|감사|재밌|재미있|기뻤|기쁘|신났|불안|걱정|아쉬/.test(text),
    detail:/꽃|나무|바람|햇살|햇빛|새소리|이야기|대화|장미|벚꽃|김치|국수|비빔밥|찌개|불고기|커피|빵|책을|책이|독서|영화|노래|맛있|맛없/.test(text),
    activity:/산책|공원|걷|걸었|먹|식사|음식|밥|요리|만들|갔|다녀|만났|봤|보았|읽|청소|쉬었|쉬고|운동|시장|병원|집에서|집에/.test(text),
    stop:/쉬고 싶|그만|여기까지|피곤|지쳤|기억 안|기억이 안|모르겠|생각이 안/.test(turns.at(-1)?.answer||'')};
}
export function localReply({turns,photos=[],todayEvents=[]}) {
  const guarded=conversationGuard({turns});if(guarded)return guarded;
  const c=contextOf(turns);
  const pending=todayEvents.filter(e=>e.completed!==true);
  if(!turns.length)return {question:MEMORABLE_OPENING+(photos.length?' 고르신 사진을 보며 떠올려도 좋아요.':''),ready:false};
  if(c.stop)return c.hasStory&&turns.some(t=>t.answer.trim()&&!/쉬고 싶|그만|여기까지|피곤|지쳤|기억.*안|모르겠/.test(t.answer))?{question:'들려주신 이야기로 오늘의 일기를 정리해 볼게요.',ready:true}:{question:'괜찮아요. 잠시 쉬었다가 이어가도 좋아요.',ready:false,rest:true};
  if(c.hasStory&&((c.activity&&c.feeling&&(c.detail||c.text.length>=30))||turns.length>=6))return {question:'들려주신 이야기로 오늘의 일기를 정리해 볼게요.',ready:true};
  const choices=[];
  if(!c.detail){if(/산책|공원|걷|걸었/.test(c.text))choices.push('걸으면서 무엇이 가장 눈에 들어오셨나요?');else if(/먹|식사|음식|밥/.test(c.text))choices.push('어떤 음식을 드셨나요?');else if(/시장|장보|장 봤/.test(c.text))choices.push('시장에서 무엇을 보고 오셨나요?');}
  if(c.hasStory&&!c.feeling)choices.push('그 시간을 보내고 나니 기분이 어떠셨어요?');
  if(!c.activity)choices.push('오늘 하신 일 중 한 가지만 편하게 들려주시겠어요?');
  if(!c.detail)choices.push('그때 기억에 남는 것이 하나 있었나요?');
  const question=choices.find(q=>!turns.some(t=>t.question===q));
  if(question)return {question,ready:false};
  return c.hasStory?{question:'들려주신 이야기로 오늘의 일기를 정리해 볼게요.',ready:true}:{question:'답하기 어려우면 잠시 쉬어도 괜찮아요.',ready:false,rest:true};
}
